# Third-party notices

H-logsen includes the following JavaScript assets in the source archive and the Windows wheel. Their copyright and license texts are distributed alongside the assets.

| Component | License | License text |
| --- | --- | --- |
| xterm.js | MIT | [xterm notice](app/static/vendor/xterm/LICENSE) |
| xterm.js Fit addon | MIT | [Fit addon notice](app/static/vendor/xterm-fit/LICENSE) |
| Moment.js | MIT | [Moment notice](app/static/vendor/moment/LICENSE) |
| Highlight.js | BSD 3-Clause | [Highlight notice](app/static/vendor/highlight/LICENSE) |

Python dependencies are resolved separately at installation from the project metadata. Their distribution terms remain with their respective packages. Microsoft Edge WebView2 is a Windows prerequisite installed separately.

The source archive includes a copy of the [Loghub license](data/raw/LOGHUB_LICENSE.txt) for reference. Obtain BGL from [Loghub](https://github.com/logpai/loghub) and follow its terms. The packaged demo uses synthetic data. Public redistribution of datasets, papers, project logs or model artifacts requires a separate review.

These notices apply to the named components. The licensing decision for H-logsen's own source remains separate.
